/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CE.DAO;

import CE.Bean.Produtos;
import CE.Connection.ConnectionFactory;

import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.util.*;

/**
 *
 * @author amelia
 */
public class ProdutosDAO {
    
    
    
    // INSERE
    public void create(Produtos p){
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("INSERT INTO produtos (Nome_do_Produto,Data_de_Validade,Codigo_do_Produto,Quantidade,Estado,Categoria,Estado_de_Uso)VALUES(?,?,?,?,?,?,?)");
            
            stmt.setString(1, p.getNome_do_Produto());
            stmt.setString(2, p.getData_de_Validade());
            stmt.setInt(3, p.getCodigo_do_Produto());
            stmt.setInt(4, p.getQuantidade());
            stmt.setString(5, p.getEstado());
            stmt.setString(6, p.getCategoria());
            stmt.setString(7, p.getEstado_de_Uso());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar! "+ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
        }
        
    }
    
    
    
    
    
    
    
    // ATUALIZAR
    public void update(Produtos p){
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("UPDATE produtos SET Nome_do_Produto = ?,Data_de_Validade = ?,Quantidade = ?,Estado = ?,Categoria = ?,Estado_de_Uso = ? WHERE Codigo_do_Produto = ?");
            
            stmt.setString(1, p.getNome_do_Produto());
            stmt.setString(2, p.getData_de_Validade());
            stmt.setInt(3, p.getQuantidade());
            stmt.setString(4, p.getEstado());
            stmt.setString(5, p.getCategoria());
            stmt.setString(6, p.getEstado_de_Uso());
            stmt.setInt(7, p.getCodigo_do_Produto());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar! "+ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
        }
        
    }
    
    
    
    
    
    
    
    
    
    
    
    // ATUALIZAR USO
    public void updateTipo(Produtos p){
        
       Connection con = ConnectionFactory.getConnection();
       PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("UPDATE produtos SET Estado_de_Uso = ?");
            
            stmt.setString(1, "Sim");
            
            stmt.executeUpdate();
                  
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar! "+ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
        }
        
    }
    
    
    
    
    
    
    // CARREGA TABELA
  
    public List<Produtos> read(){

            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            
            List<Produtos> produtos = new ArrayList<>();
        try {
            stmt = con.prepareStatement("SELECT * FROM produtos");
            rs = stmt.executeQuery();
            
            while(rs.next()){
                
                Produtos produto = new Produtos();
                
                produto.setid(rs.getInt("id"));
                produto.setNome_do_Produto(rs.getString("Nome_do_Produto"));
                produto.setData_de_Validade(rs.getString("Data_de_Validade"));
                produto.setCodigo_do_Produto(rs.getInt("Codigo_do_Produto"));
                produto.setQuantidade(rs.getInt("Quantidade"));
                produto.setEstado(rs.getString("Estado"));
                produto.setCategoria(rs.getString("Categoria"));
                produto.setEstado_de_Uso(rs.getString("Estado_de_Uso"));
                
                produtos.add(produto);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return produtos; 
            
    }
    
    
    
    
    
    // MATERIAIS DE ENTRADA
    
    public List<Produtos> readEntrada(){

            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            
            List<Produtos> produtos = new ArrayList<>();
        try {
            stmt = con.prepareStatement("SELECT * FROM produtos LIMIT 30");
            rs = stmt.executeQuery();
            
            while(rs.next()){
                
                Produtos produto = new Produtos();
                
                produto.setid(rs.getInt("id"));
                produto.setNome_do_Produto(rs.getString("Nome_do_Produto"));
                produto.setData_de_Validade(rs.getString("Data_de_Validade"));
                produto.setCodigo_do_Produto(rs.getInt("Codigo_do_Produto"));
                produto.setQuantidade(rs.getInt("Quantidade"));
                produto.setEstado(rs.getString("Estado"));
                produto.setCategoria(rs.getString("Categoria"));
                produto.setEstado_de_Uso(rs.getString("Estado_de_Uso"));
                
                produtos.add(produto);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return produtos; 
            
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // MATERIAIS PARADOS
    
      public List<Produtos> readUso(){

            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            
            List<Produtos> produtos = new ArrayList<>();
        try {
            stmt = con.prepareStatement("SELECT * FROM produtos WHERE Estado_de_Uso = 'Não' ");
            rs = stmt.executeQuery();
            
            while(rs.next()){
                
                Produtos produto = new Produtos();
                
                produto.setid(rs.getInt("id"));
                produto.setNome_do_Produto(rs.getString("Nome_do_Produto"));
                produto.setData_de_Validade(rs.getString("Data_de_Validade"));
                produto.setCodigo_do_Produto(rs.getInt("Codigo_do_Produto"));
                produto.setQuantidade(rs.getInt("Quantidade"));
                produto.setEstado(rs.getString("Estado"));
                produto.setCategoria(rs.getString("Categoria"));
                produto.setEstado_de_Uso(rs.getString("Estado_de_Uso"));
                
                produtos.add(produto);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return produtos; 
            
    }
    
    
    
 
    
      
      
      
    
    // DELETA
    public void delete(Produtos p){
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("DELETE FROM produtos WHERE Codigo_do_Produto = ?");
            
            stmt.setInt(1, p.getCodigo_do_Produto());
            
            stmt.executeUpdate();
             
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir! "+ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
        }
    }
    
    
    
    
    
    
    // PESQUISA 

    public List<Produtos> readNomeProduto(String nomep){

            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            
            List<Produtos> produtos = new ArrayList<>();
        try {
            stmt = con.prepareStatement("SELECT * FROM produtos WHERE Nome_do_Produto LIKE ?");
            stmt.setString(1, "%"+nomep+"%");
            rs = stmt.executeQuery();
            
            while(rs.next()){
                
                Produtos produto = new Produtos();
                
                produto.setid(rs.getInt("id"));
                produto.setNome_do_Produto(rs.getString("Nome_do_Produto"));
                produto.setData_de_Validade(rs.getString("Data_de_Validade"));
                produto.setCodigo_do_Produto(rs.getInt("Codigo_do_Produto"));
                produto.setQuantidade(rs.getInt("Quantidade"));
                produto.setEstado(rs.getString("Estado"));
                produto.setCategoria(rs.getString("Categoria"));
                produto.setEstado_de_Uso(rs.getString("Estado_de_Uso"));
                
                produtos.add(produto);
            }
            
        } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado!");
        }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return produtos; 
            
    }
}


