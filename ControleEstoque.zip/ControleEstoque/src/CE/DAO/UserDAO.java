/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CE.DAO;

import CE.Bean.Produtos;
import CE.Bean.User;
import CE.Connection.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author amelia
 */
public class UserDAO {
    public void create(User u){
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("INSERT INTO usuarios (Nome_completo,Email,Nome_do_Usuario,Senha,Confirmar_Senha,Tipo_User)VALUES(?,?,?,?,?,?)");
            
            stmt.setString(1, u.getNome_Completo());
            stmt.setString(2, u.getEmail());
            stmt.setString(3, u.getNome_do_Usuario());
            stmt.setString(4, u.getSenha());
            stmt.setString(5, u.getConfirmar_Senha());
            stmt.setString(6, u.getTipo_User());
            
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar!"+ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
        }
        
    }
    
    
    
    
    
    
    
   // CARREGA TABELA
    
        public List<User> read(){

            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            
            List<User> usuarios = new ArrayList<>();
        try {
            stmt = con.prepareStatement("SELECT * FROM usuarios");
            rs = stmt.executeQuery();
            
            while(rs.next()){
                
                User usuario = new User();
                
                usuario.setid(rs.getInt("id"));
                usuario.setNome_Completo(rs.getString("Nome_Completo"));
                usuario.setEmail(rs.getString("Email"));
                usuario.setNome_do_Usuario(rs.getString("Nome_do_Usuario"));
                usuario.setTipo_User(rs.getString("Tipo_User"));
                
                usuarios.add(usuario);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return usuarios; 
           
        }    
      
        
        
        
        
//    LOGIN
     public boolean checkLogin(String login, String senha){

            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            boolean check = false;
            
        try {
            stmt = con.prepareStatement("SELECT * FROM usuarios WHERE Nome_do_Usuario = ? AND Senha = ?");
            stmt.setString(1, login);
            stmt.setString(2, senha);
            rs = stmt.executeQuery();
            
            if(rs.next()){
                check = true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
                
        }  
        return check;
        }
     
     
     
     
     
     
     // ADMIN GERAL
     public boolean checkAdmin(String login, String senha){

            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            boolean check = false;
            
        try {
            stmt = con.prepareStatement("SELECT * FROM admin WHERE admin = ? AND senha = ?");
            stmt.setString(1, login);
            stmt.setString(2, senha);
            rs = stmt.executeQuery();
            
            if(rs.next()){
                check = true;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutosDAO.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
                
        }  
        return check;
        }
        
     
     
     
     
     
     
     
     
//        DELETAR PRODUTOS
    public void delete(User u){
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("DELETE FROM usuarios WHERE Nome_do_Usuario = ?");
            
            stmt.setString(1, u.getNome_do_Usuario());
            
            stmt.executeUpdate();
             
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir! "+ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
        }
        
       }
    
    
    
    
    
    
    
    
    
    
    
    // PESQUISAR
    
     public List<User> readNomeUsuario(String nomeu){

            Connection con = ConnectionFactory.getConnection();
            PreparedStatement stmt = null;
            ResultSet rs = null;
            
            List<User> usuarios = new ArrayList<>();
        try {
            stmt = con.prepareStatement("SELECT * FROM usuarios WHERE Nome_Completo LIKE ?");
            stmt.setString(1, "%"+nomeu+"%");
            rs = stmt.executeQuery();
            
            if(nomeu == null){
                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado!");
            }else{
            while(rs.next()){
                
                User usuario = new User();
                
                usuario.setid(rs.getInt("id"));
                usuario.setNome_Completo(rs.getString("Nome_Completo"));
                usuario.setEmail(rs.getString("Email"));
                usuario.setNome_do_Usuario(rs.getString("Nome_do_Usuario"));
                usuario.setTipo_User(rs.getString("Tipo_User"));
                usuarios.add(usuario);
            }
           }
        } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado!");
        }finally{
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return usuarios; 
     }
     
     
     
     // ATUALIZAR
    public void update(User u){
        
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("UPDATE usuarios SET Nome_Completo = ?,Email = ?,Tipo_User = ?,Senha = ?,Confirmar_Senha = ? WHERE Nome_do_Usuario = ?");
            
            stmt.setString(1, u.getNome_Completo());
            stmt.setString(2, u.getEmail());
            stmt.setString(3, u.getTipo_User());
            stmt.setString(4, u.getSenha());
            stmt.setString(5, u.getConfirmar_Senha());
            stmt.setString(6, u.getNome_do_Usuario());
            
            stmt.executeUpdate();
            
            
            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar! "+ex);
        }finally{
            ConnectionFactory.closeConnection(con, stmt);
        }
        
    }
 
    }





     
