-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 14-Jun-2017 às 10:45
-- Versão do servidor: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cee`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `admin`
--

CREATE TABLE `admin` (
  `id` int(8) NOT NULL,
  `admin` varchar(15) NOT NULL,
  `senha` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `admin`
--

INSERT INTO `admin` (`id`, `admin`, `senha`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `Nome_do_Produto` varchar(100) NOT NULL,
  `Data_de_Validade` varchar(100) NOT NULL,
  `Codigo_do_Produto` varchar(100) NOT NULL,
  `Quantidade` varchar(100) NOT NULL,
  `Estado` varchar(100) NOT NULL,
  `Categoria` varchar(100) NOT NULL,
  `Estado_de_Uso` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `produtos`
--

INSERT INTO `produtos` (`id`, `Nome_do_Produto`, `Data_de_Validade`, `Codigo_do_Produto`, `Quantidade`, `Estado`, `Categoria`, `Estado_de_Uso`) VALUES
(25, 'Cadeira', '20/15/2020', '3214741', '10', 'E', 'Didaticos', 'Sim'),
(22, 'Mesa', '20/20/2000', '123445', '120', 'E', 'Cozinha', 'Sim');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(8) NOT NULL,
  `Nome_Completo` varchar(60) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `Nome_do_Usuario` varchar(60) NOT NULL,
  `Tipo_User` varchar(15) NOT NULL,
  `Senha` varchar(60) NOT NULL,
  `Confirmar_Senha` varchar(60) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `Nome_Completo`, `Email`, `Nome_do_Usuario`, `Tipo_User`, `Senha`, `Confirmar_Senha`) VALUES
(9, 'Alisson Alves', 'alisson.a.m88@gmail.com', 'AlissonSteen', 'Aux. de Limpeza', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
