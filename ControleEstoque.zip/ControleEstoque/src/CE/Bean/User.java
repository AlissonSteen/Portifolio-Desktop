/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CE.Bean;

/**
 *
 * @author amelia
 */
public class User {
   private int id;
   private String Nome_Completo;

    public int getid() {
        return id;
    }

    public void setid(int id) {
        this.id = id;
    }

    public String getNome_Completo() {
        return Nome_Completo;
    }

    public void setNome_Completo(String Nome_Completo) {
        this.Nome_Completo = Nome_Completo;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getNome_do_Usuario() {
        return Nome_do_Usuario;
    }

    public void setNome_do_Usuario(String Nome_do_Usuario) {
        this.Nome_do_Usuario = Nome_do_Usuario;
    }

    public String getTipo_User() {
        return Tipo_User;
    }

    public void setTipo_User(String Tipo_User) {
        this.Tipo_User = Tipo_User;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    public String getConfirmar_Senha() {
        return Confirmar_Senha;
    }

    public void setConfirmar_Senha(String Confirmar_Senha) {
        this.Confirmar_Senha = Confirmar_Senha;
    }
    
   private String Email;
   private String Nome_do_Usuario;
   private String Tipo_User;
   private String Senha;
   private String Confirmar_Senha;

}
