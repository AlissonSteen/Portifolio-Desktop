/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CE.Bean;

import java.util.List;

/**
 *
 * @author amelia
 */
public class Produtos {

    private int id;
    private String Nome_do_Produto;
    private String Data_de_Validade;
    private int Codigo_do_Produto;
    private int Quantidade;
    private String Estado;
    private String Categoria;
    private String Estado_de_Uso;

    public int getid() {
        return id;
    }

    public void setid(int id) {
        this.id = id;
    }

    public String getNome_do_Produto() {
        return Nome_do_Produto;
    }

    public void setNome_do_Produto(String Nome_do_Produto) {
        this.Nome_do_Produto = Nome_do_Produto;
    }

    public String getData_de_Validade() {
        return Data_de_Validade;
    }

    public void setData_de_Validade(String Data_de_Validade) {
        this.Data_de_Validade = Data_de_Validade;
    }

    public int getCodigo_do_Produto() {
        return Codigo_do_Produto;
    }

    public void setCodigo_do_Produto(int Codigo_do_Produto) {
        this.Codigo_do_Produto = Codigo_do_Produto;
    }

    public int getQuantidade() {
        return Quantidade;
    }

    public void setQuantidade(int Quantidade) {
        this.Quantidade = Quantidade;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String Categoria) {
        this.Categoria = Categoria;
    }

    public String getEstado_de_Uso() {
        return Estado_de_Uso;
    }

    public void setEstado_de_Uso(String Estado_de_Uso) {
        this.Estado_de_Uso = Estado_de_Uso;
    }

}
