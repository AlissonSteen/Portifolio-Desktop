-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 11-Abr-2017 às 14:01
-- Versão do servidor: 5.7.9
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cee`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `produtos`
--

DROP TABLE IF EXISTS `produtos`;
CREATE TABLE IF NOT EXISTS `produtos` (
  `ID_Produto` int(8) NOT NULL AUTO_INCREMENT,
  `Nome_do_Produto` varchar(60) NOT NULL,
  `Data_de_Validade` int(8) NOT NULL,
  `Codigo_do_Produto` int(8) NOT NULL,
  `Quantidade` int(8) NOT NULL,
  `Estado` varchar(1) NOT NULL,
  `Categoria` varchar(4) NOT NULL,
  `Estado_de_Uso` varchar(2) NOT NULL,
  PRIMARY KEY (`ID_Produto`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `ID_Usuario` int(8) NOT NULL AUTO_INCREMENT,
  `Nome_Completo` varchar(60) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `Nome_do_Usuario` varchar(60) NOT NULL,
  `Senha` varchar(60) NOT NULL,
  `Confirmar_Senha` varchar(60) NOT NULL,
  PRIMARY KEY (`ID_Usuario`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
